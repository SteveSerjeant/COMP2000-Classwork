import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("81457830-b5d9-420a-9a2c-0a9fe1221169")
public class Class {
}
