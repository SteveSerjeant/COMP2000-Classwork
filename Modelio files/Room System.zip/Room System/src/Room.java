import com.modeliosoft.modelio.javadesigner.annotations.mdl;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("4622bf27-66a9-4251-a335-d46002b98dea")
public class Room {
    @objid ("3eb74375-773a-4208-b2c1-bc28c1c11065")
    public String mode;

    @mdl.prop
    @objid ("b112db70-87b2-4b21-a17e-6d6ed95cfc71")
    private Room ;

    @mdl.propgetter
    public Room get() {
        // Automatically generated method. Please do not modify this code.
        return this.;
    }

    @mdl.propsetter
    public void set(Room value) {
        // Automatically generated method. Please do not modify this code.
        this. = value;
    }

    @objid ("627797de-d0f2-4f10-ba96-a6bac822c802")
    public void locked() {
    }

    @objid ("62bd18f3-b597-40c5-bb2e-544b0ba00d04")
    public void Unlocked() {
    }

}
