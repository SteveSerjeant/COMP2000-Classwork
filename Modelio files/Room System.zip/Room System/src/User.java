import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("ad3c9ad1-587f-48d9-97a6-e19b50593eb2")
public class User {
    @objid ("2435c0b1-3a27-4e77-861d-818b4ad405af")
    public Room room;

}
